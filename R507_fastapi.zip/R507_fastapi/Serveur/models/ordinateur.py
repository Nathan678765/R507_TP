import os
from typing import Optional
from sqlmodel import Field, SQLModel

class Ordinateur(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    hostname : str = Field(default="test")
    os_name: str = Field(default="Debian")
    os_version: str = Field(default="11")
    
    def init_hostname(self):
        cmd = os.popen("hostname")
        self.hostname = cmd.read().strip()
    
    def init_os_name_version(self):
        cmd = os.popen("lsb_release -a").readlines()
        line_deux = cmd[2].split()
        line_trois = cmd[3].split()
        self.os_name = line_deux[2 + " " + 3]
        self.os_version = line_trois[2]
        
    def update_ordinateur(self):
        self.init_hostname()
        self.init_os_name_version()

    def __str__(self):
        return f"#{self.id} | hostname {self.hostname} os_name {self.os_name} os_version {self.os_version}"
    
    def __repr__(self):
        return f"<Cpu(id='{self.id}', hostname='{self.hostname}', os_name='{self.os_name}' , os_version='{self.os_version}')>"

def main():
    O1 = Ordinateur(os_name="Windows 10", os_version="test", hostname="xr"))
    print(O1)
    print(O1.update_ordinateur())
    
if __name__ == "__main__":
    main()