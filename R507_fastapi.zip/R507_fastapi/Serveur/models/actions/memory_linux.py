def execu_script() -> str:
    return "12"